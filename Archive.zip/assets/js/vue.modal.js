      $(".toggle-modal").click(function() {
            $(".modal").toggleClass("is-active");
        });