<section class="hero is-100 background1 ">
	<div class="row flex height100 paddingtopbottom">
				<div class="col-md-4"></div>
				<div class="col-md-4">
					<div class="bg_white">
					
						<div class="padding30px">
							<p class="login">Daftar</p>
							<form class="margin-top-30px">
								<input class="input" type="text" name="name" placeholder="Masukan Username">
								<input class="input margintop20px" type="email" name="password" placeholder="Masukan email">
								<div class="row margintop20px">
									<div class="col-md-6">
										<input class="input " type="password" name="password" placeholder="Masukan password">
									</div>
									<div class="col-md-6">
										<input class="input " type="email" name="password" placeholder="Masukan ulang password">
									</div>
								</div>
								
								<div class=" margintop20px">
									<label class="checkbox">
											<input type="checkbox">
											Terima berita mingguan dan pemberitahuan lainnya
										</label>
								</div>
								<a class="button is-primary width100 margintop20px" href="">Daftar</a>
								<div class="center margintop20px">atau</div>

								<a class="button width100 is-info margintop20px">
									<span class="icon">
										<i class="fa fa-facebook"></i>
									</span>
									<span>Facebook</span>
								</a>

								<a class="button width100 is-danger margintop20px">
									<span class="icon">
										<i class="fa fa-google"></i>
									</span>
									<span>Google</span>
								</a>
								<hr>
								<div class="center">Sudah memiliki akun?<a class="" href=""> Masuk</a></div>
								
							</form>
						</div>
					</div>
				</div>
				<div class="col-md-4"></div>
			</div>
</section>