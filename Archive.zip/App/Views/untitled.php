<div class='buttons'>                                        
       <div class='field is-grouped'>
               <button v-on:click='launch' class='button is-light'>Masuk</button>
          

<div>
  <a class='button is-primary'>
     Daftar
</a>
</div>                            
</div>
</div>
