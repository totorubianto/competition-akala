<div class="alert alert-danger" role="alert">
  404 not found
</div>